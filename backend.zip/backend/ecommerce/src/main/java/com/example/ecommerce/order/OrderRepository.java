package com.example.ecommerce.order;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends JpaRepository<Order, Long> {
    Optional<Order> findByIdAndUserId(Long id, Long userId);

    List<Order> findByUserIdOrderByPlacedAtDesc(Long userId);

    void deleteByUserId(Long userId);

}
